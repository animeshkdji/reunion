Run DB Tables.sql file in mysql
Open command prompt
Run `npm i`
`npm run init`
`npm start`
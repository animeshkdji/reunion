import React, { useState } from 'react';
import axios from 'axios';

const TaskForm: React.FC = () => {
    const [title, setTitle] = useState<string>('');
    const [description, setDescription] = useState<string>('');
    const [start_time, setStartTime] = useState<string>('');
    const [end_time, setEndTime] = useState<string>('');
    const [priority, setPriority] = useState<number>(1);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        axios.post('http://localhost:3001/tasks', {
            title,
            description,
            start_time: new Date(start_time),
            end_time: new Date(end_time),
            priority,
            status: 'pending',
            completed: false
        }).then(response => {
            console.log(response.data);
        });
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>Title</label>
                <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
            </div>
            <div>
                <label>Description</label>
                <textarea value={description} onChange={(e) => setDescription(e.target.value)}></textarea>
            </div>
            <div>
                <label>Start Time</label>
                <input type="datetime-local" value={start_time} onChange={(e) => setStartTime(e.target.value)} />
            </div>
            <div>
                <label>End Time</label>
                <input type="datetime-local" value={end_time} onChange={(e) => setEndTime(e.target.value)} />
            </div>
            <div>
                <label>Priority</label>
                <input type="number" min="1" max="5" value={priority} onChange={(e) => setPriority(Number(e.target.value))} />
            </div>
            <button type="submit">Create Task</button>
        </form>
    );
};

export default TaskForm;

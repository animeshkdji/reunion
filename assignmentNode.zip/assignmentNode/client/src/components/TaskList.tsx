import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Task {
    id: number;
    title: string;
    description?: string;
    start_time: string;
    end_time: string;
    priority: number;
    status: 'pending' | 'finished';
    completed: boolean;
}

const TaskList: React.FC = () => {
    const [tasks, setTasks] = useState<Task[]>([]);
    const [filter, setFilter] = useState<{ priority?: number, status?: string }>({});
    const [sort, setSort] = useState<string>('start_time');

    useEffect(() => {
        axios.get('http://localhost:3001/tasks')
            .then(response => setTasks(response.data));
    }, []);

    const fetchFilteredTasks = () => {
        axios.get('http://localhost:3001/tasks/filter', { params: filter })
            .then(response => setTasks(response.data));
    };

    const fetchSortedTasks = () => {
        axios.get('http://localhost:3001/tasks/sort', { params: { sortBy: sort } })
            .then(response => setTasks(response.data));
    };

    useEffect(() => {
        fetchFilteredTasks();
    }, [filter]);

    useEffect(() => {
        fetchSortedTasks();
    }, [sort]);

    const handlePriorityChange = (id: number, priority: number) => {
        axios.put(`http://localhost:3001/tasks/${id}`, { priority })
            .then(response => {
                setTasks(tasks.map(task => task.id === id ? { ...task, priority } : task));
            });
    };

    const handleCompletionChange = (id: number, completed: boolean) => {
        const status = completed ? 'finished' : 'pending';
        axios.put(`http://localhost:3001/tasks/${id}`, { status, completed })
            .then(response => {
                setTasks(tasks.map(task => task.id === id ? { ...task, status, completed } : task));
            });
    };

    return (
        <div className="task-list">
            <h2>Task List</h2>
            <div className="filter-sort">
                <div>
                    <label>Filter by Priority</label>
                    <input type="number" min="1" max="5" onChange={(e) => setFilter({ ...filter, priority: Number(e.target.value) })} />
                </div>
                <div>
                    <label>Filter by Status</label>
                    <select onChange={(e) => setFilter({ ...filter, status: e.target.value })}>
                        <option value="pending">Pending</option>
                        <option value="finished">Finished</option>
                    </select>
                </div>
                <div>
                    <label>Sort by</label>
                    <select onChange={(e) => setSort(e.target.value)}>
                        <option value="start_time">Start Time</option>
                        <option value="end_time">End Time</option>
                    </select>
                </div>
            </div>
            {tasks.map(task => (
                <div key={task.id}>
                    <h3>{task.title}</h3>
                    <p>{task.description}</p>
                    <p>Start Time: {new Date(task.start_time).toLocaleString()}</p>
                    <p>End Time: {new Date(task.end_time).toLocaleString()}</p>
                    <p>Priority: {task.priority}</p>
                    <p className="status">{task.status === 'pending' ? 'Pending' : 'Finished'}</p>
                    <div className="task-edit">
                        <label>Priority</label>
                        <select value={task.priority} onChange={(e) => handlePriorityChange(task.id, Number(e.target.value))}>
                            <option value={1}>1</option>
                            <option value={2}>2</option>
                            <option value={3}>3</option>
                            <option value={4}>4</option>
                            <option value={5}>5</option>
                        </select>
                        <label>
                            <input
                                type="checkbox"
                                checked={task.completed}
                                onChange={(e) => handleCompletionChange(task.id, e.target.checked)}
                            />
                            Completed
                        </label>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default TaskList;

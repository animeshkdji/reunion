import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import Task from './models/task';
import cors from "cors";

const app = express();
app.use(bodyParser.json());
app.use(cors());

// Create a task
app.post('/tasks', async (req: Request, res: Response) => {
    const { title, description, start_time, end_time, priority } = req.body;
    const task = await Task.create({ title, description, start_time: new Date(start_time), end_time: new Date(end_time), priority, status: 'pending', completed: false });
    res.json(task);
});

// Get all tasks
app.get('/tasks', async (req: Request, res: Response) => {
    const tasks = await Task.findAll();
    res.json(tasks);
});

// Filter and sort tasks
app.get('/tasks/filter', async (req: Request, res: Response) => {
    const { priority, status } = req.query;
    const where: any = {};
    if (priority) where.priority = priority;
    if (status) where.status = status;
    const tasks = await Task.findAll({ where });
    res.json(tasks);
});

app.get('/tasks/sort', async (req: Request, res: Response) => {
    const { sortBy } = req.query;
    const tasks = await Task.findAll({
        order: [[sortBy as string, 'ASC']]
    });
    res.json(tasks);
});

// Update a task
app.put('/tasks/:id', async (req: Request, res: Response) => {
    const { id } = req.params;
    const { title, description, start_time, end_time, priority, status, completed } = req.body;
    const task = await Task.findByPk(id);
    if (task) {
        if (status === 'finished') {
            task.end_time = new Date();
        }
        await Task.update({ title, description, start_time, end_time, priority, status, completed }, { where: { id } });
        res.json({ success: true });
    } else {
        res.status(404).json({ error: 'Task not found' });
    }
});

// Delete a task
app.delete('/tasks/:id', async (req: Request, res: Response) => {
    const { id } = req.params;
    await Task.destroy({ where: { id } });
    res.json({ success: true });
});

// Get task statistics
app.get('/tasks/stats', async (req: Request, res: Response) => {
    const tasks = await Task.findAll();
    const totalCount = tasks.length;
    const completedCount = tasks.filter(task => task.status === 'finished').length;
    const pendingCount = tasks.filter(task => task.status === 'pending').length;
    const completedTasks = tasks.filter(task => task.status === 'finished');
    const pendingTasks = tasks.filter(task => task.status === 'pending');

    const calculateTime = (start_time: Date, end_time: Date) => (end_time.getTime() - start_time.getTime()) / (1000 * 60 * 60);

    const totalTimeLapsed = pendingTasks.reduce((sum, task) => sum + calculateTime(task.start_time, new Date()), 0);
    const balanceEstimateTime = pendingTasks.reduce((sum, task) => {
        const end_time = new Date(task.end_time);
        const currentTime = new Date();
        const timeLeft = Math.max(0, (end_time.getTime() - currentTime.getTime()) / (1000 * 60 * 60));
        return sum + timeLeft;
    }, 0);
    const totalCompletionTime = completedTasks.reduce((sum, task) => sum + calculateTime(task.start_time, task.end_time), 0);
    const averageCompletionTime = totalCompletionTime / completedCount || 0;

    res.json({
        totalCount,
        completedCount,
        pendingCount,
        percentCompleted: (completedCount / totalCount) * 100,
        percentPending: (pendingCount / totalCount) * 100,
        totalTimeLapsed,
        balanceEstimateTime,
        averageCompletionTime
    });
});

app.listen(3001, () => {
    console.log('Server is running on port 3001');
});

import { Sequelize, DataTypes, Model, Optional } from 'sequelize';

const sequelize = new Sequelize('testdb', 'root', '5117', {
    host: 'localhost',
    dialect: 'mysql'
});

interface TaskAttributes {
    id: number;
    title: string;
    description?: string;
    start_time: Date;
    end_time: Date;
    priority: number;
    status: 'pending' | 'finished';
    completed: boolean;
}

interface TaskCreationAttributes extends Optional<TaskAttributes, 'id'> {}

class Task extends Model<TaskAttributes, TaskCreationAttributes> implements TaskAttributes {
    public id!: number;
    public title!: string;
    public description?: string;
    public start_time!: Date;
    public end_time!: Date;
    public priority!: number;
    public status!: 'pending' | 'finished';
    public completed!: boolean;
    // Sequelize will automatically manage these fields
    public readonly createdAt!: Date;
    public readonly updatedAt!: Date;
}

Task.init(
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        title: {
            type: DataTypes.STRING,
            allowNull: false
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        start_time: {
            type: DataTypes.DATE,
            allowNull: false,
            field: 'start_time'
        },
        end_time: {
            type: DataTypes.DATE,
            allowNull: false,
            field: 'end_time'
        },
        priority: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: { min: 1, max: 5 }
        },
        status: {
            type: DataTypes.ENUM('pending', 'finished'),
            defaultValue: 'pending'
        },
        completed: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        }
    },
    {
        sequelize,
        modelName: 'Task',
        timestamps: true, // Enable Sequelize to handle `createdAt` and `updatedAt`
        underscored: true // Use snake_case column names
    }
);

sequelize.sync().then(() => {
    console.log('Tasks table has been updated.');
});

export default Task;
